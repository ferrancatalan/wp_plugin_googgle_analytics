=== Plugin Name ===
Donate link: https://ferrancatalan.com/
Tags: google analytics, tracking code, easy, add
Requires at least: 4.0.1
Tested up to: 5.2.2
Stable tag: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy way to add your google analytics tracking code to your wordpress blog.

== Description ==

With this plugin you can add your google analytics tracking code to your wordpress blog and 
filter your traffic when:

*   Admin user is logged.
*   Editor user is logged.
*   404 page.

== Installation ==

How to install and track your blog

1. Upload zip folder to the `/wp-content/plugins/` directory or install from Plugins menu in wordpress.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to settings> Google analytics code.
4. Copy your tracking code and press save button.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot